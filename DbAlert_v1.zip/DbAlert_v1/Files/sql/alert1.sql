﻿select case when  DB_ID('dbname') IS NOT NULL then 1 else 0 end 

