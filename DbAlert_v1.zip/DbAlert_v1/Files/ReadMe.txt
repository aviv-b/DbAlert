﻿DbAlerts  v1  by https://github.com/aviv-b
==============================================
Files:

	 appSettings.json - Application settings file.
		
	 log.txt - Application log file. 
	
==============================================	 
Settings:
	
	Log 
	===
		> maxDays - The log file will deleted after X days. 

		> maxMBSize - The log file will deleted after reaching X mb size. 

	
	Alerts 
	======
		> name 

		> odbcConnString  - Odbc string connection. Read more: https://www.connectionstrings.com/ 
							* recommendation: 
								 - use windows odbc connection 
								 - use sql read only user authtication
								 
		> queryCondition  - Sql query condition for alert 
		
		> triggerValue - An string value comparred against queryCondition result if they equals Alert message will send 
		
		> alertMessage - The Alert Message 

		> active  - Enable / Disable the alert operation 
			- true  
			- false
			
		> mails  - List of repcients mail boxs
	
	
	Smtp 
	====
		> server 
		> address 
		> port
		> username 
		> password 

	Exchange
	========
		> server 
		> address
		> username 
		> password  - * recommand creating mail account spesific for alerts only !! 
			


==============================================	
How To Run: 

	> Use windows 'Task Scheduler' and create a scheduler task.
    > Specify running times: minutes / hourly / daily / weekly etc.
	> Choose an action: navigate to .exe file. 

===============================================
Fix Problems: 

	> Mail in gibrish - make sure 'appSettings.json' file encoding in uft8.

	> Any other issues will saved on 'log.txt'.

